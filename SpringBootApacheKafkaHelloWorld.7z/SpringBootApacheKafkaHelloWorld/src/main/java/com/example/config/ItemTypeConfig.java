
package com.example.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration

@EnableConfigurationProperties

@ConfigurationProperties(prefix = "itemtypes")

public class ItemTypeConfig {
	private Map<String, String> psatypes;

	public Map<String, String> getPsatypes() {
		return psatypes;
	}

	public void setPsatypes(Map<String, String> psatypes) {
		this.psatypes = psatypes;
	}

	public ItemTypeConfig(Map<String, String> psatypes) {
		super();
		this.psatypes = psatypes;
	}
}
