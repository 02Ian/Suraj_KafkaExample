
package com.example.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration

@EnableConfigurationProperties

@ConfigurationProperties

public class YAMLConfig {
	private String pdipath;
	private String pdiUsername;
	private String pdiPassword;
	private String domain = "";
	private String inputFileName;
	private String inputFolder;
	private String multiplePSAsPerStore;

	public String getPdipath() {
		return pdipath;
	}

	public void setPdipath(String pdipath) {
		this.pdipath = pdipath;
	}

	public String getPdiUsername() {
		return pdiUsername;
	}

	public void setPdiUsername(String pdiUsername) {
		this.pdiUsername = pdiUsername;
	}

	public String getPdiPassword() {
		return pdiPassword;
	}

	public void setPdiPassword(String pdiPassword) {
		this.pdiPassword = pdiPassword;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getInputFileName() {
		return inputFileName;
	}

	public void setInputFileName(String inputFileName) {
		this.inputFileName = inputFileName;
	}

	public String getInputFolder() {
		return inputFolder;
	}

	public void setInputFolder(String inputFolder) {
		this.inputFolder = inputFolder;
	}

	public String getMultiplePSAsPerStore() {
		return multiplePSAsPerStore;
	}

	public void setMultiplePSAsPerStore(String multiplePSAsPerStore) {
		this.multiplePSAsPerStore = multiplePSAsPerStore;
	}

	public YAMLConfig(String pdipath, String pdiUsername, String pdiPassword, String domain, String inputFileName,
			String inputFolder, String multiplePSAsPerStore) {
		super();
		this.pdipath = pdipath;
		this.pdiUsername = pdiUsername;
		this.pdiPassword = pdiPassword;
		this.domain = domain;
		this.inputFileName = inputFileName;
		this.inputFolder = inputFolder;
		this.multiplePSAsPerStore = multiplePSAsPerStore;
	}
}
