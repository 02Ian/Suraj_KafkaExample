/*
 * package com.example.csvfile;
 * 
 * import java.io.BufferedReader; import java.io.File; import
 * java.io.FileWriter; import java.io.IOException; import
 * java.io.InputStreamReader; import java.text.DateFormat; import
 * java.text.ParseException; import java.text.SimpleDateFormat; import
 * java.util.ArrayList; import java.util.Collections; import java.util.Date;
 * import java.util.List; import java.util.Map; import java.util.TreeMap;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Component;
 * 
 * import com.example.config.ItemTypeConfig; import
 * com.example.config.YAMLConfig; import com.example.model.SalesRecord; import
 * com.example.util.Constants;
 * 
 * import jcifs.smb.SmbFile; import jcifs.smb.SmbFileInputStream; import
 * lombok.extern.slf4j.Slf4j;
 * 
 * @Component
 * 
 * @Slf4j public class CSVFileProcessing {
 * 
 * @Autowired private ItemTypeConfig itemTypeConfig;
 * 
 * @Autowired private YAMLConfig myConfig;
 * 
 * public File writeSalesCSV(Map<String, List<SalesRecord>> sales, SmbFile
 * file1) throws IOException { // log.info("Start of CSV File Writer..."); File
 * sampleFile = new File("Sales-LaredoTaco-Outbound.txt"); FileWriter fileWriter
 * = null; try { fileWriter = new FileWriter(sampleFile, true); if
 * (file1.exists()) { // log.info("Yes, PDI File exist...");
 * appendSalesFile(file1, fileWriter); }
 * 
 * // Batch Header batchHeader(fileWriter); Map<String, List<SalesRecord>>
 * treeMap = new TreeMap<>(sales); for (Map.Entry<String, List<SalesRecord>>
 * entry : treeMap.entrySet()) {
 * 
 * List<SalesRecord> list = entry.getValue(); String tempLocation = null;
 * Collections.sort(list, (sr1, sr2) ->
 * sr1.getLocation().compareTo(sr2.getLocation())); int listSize = list.size();
 * 
 * for (int i = 0; i < listSize; i++) { SalesRecord tacoSales = list.get(i);
 * 
 * // Paperwork Header if (null == tempLocation) { tempLocation =
 * tacoSales.getLocation();
 * fileWriter.append(Constants.CONSTANT_PAPERWRK_HEADER);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(String.valueOf(tacoSales.getLocation()));
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(formatDate(tacoSales.getDate()));
 * fileWriter.append(Constants.NEW_LINE_SEPARATOR); } // Forms Data Value
 * fileWriter.append(Constants.CONSTANT_FORMS_DATA);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_BLANK);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(itemTypeConfig.getPsatypes().get(tacoSales.getItemType()));
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(String.valueOf(tacoSales.getTotalSales()));
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.NEW_LINE_SEPARATOR); if ((i < listSize - 1) &&
 * (!list.get(i + 1).getLocation().equals(tempLocation)) || (i == listSize - 1))
 * { tempLocation = null; }
 * 
 * // Paperwork Trailer if (null == tempLocation) {
 * fileWriter.append(Constants.CONSTANT_PAPERWRK_TRAILER);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(String.valueOf(tacoSales.getLocation()));
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(formatDate(tacoSales.getDate()));
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ONE);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.CONSTANT_ZERO);
 * fileWriter.append(Constants.NEW_LINE_SEPARATOR); } } } // Batch Trailer
 * fileWriter.append(Constants.CONSTANT_BATCH_TRAILER);
 * //log.info("File write completed...");
 * 
 * } catch (Exception e) {
 * //log.error("Error in Writing Horizon PDI Flat file sales details !!!");
 * e.printStackTrace(); } finally { try { fileWriter.flush();
 * fileWriter.close(); } catch (IOException e) {
 * //log.error("Error while flushing/closing fileWriter !!!");
 * e.printStackTrace(); } } return sampleFile; }
 * 
 * private void appendSalesFile(SmbFile file1, FileWriter fileWriter) {
 * BufferedReader fr = null; SmbFileInputStream fis = null; String line = "";
 * try { fis = new SmbFileInputStream(file1); fr = new BufferedReader(new
 * InputStreamReader(fis)); while ((line = fr.readLine()) != null) {
 * fileWriter.write(line); fileWriter.append(Constants.NEW_LINE_SEPARATOR); } }
 * catch (Exception e) {
 * //log.error("Error in reading existing PDI file from Shared Path.");
 * e.printStackTrace(); } finally { try { fis.close(); fr.close(); } catch
 * (IOException e) { // log.error("Error while closing fileReader !!!");
 * e.printStackTrace(); } } }
 * 
 * private FileWriter batchHeader(FileWriter fileWriter) throws IOException {
 * //Batch Header fileWriter.append(Constants.CONSTANT_BATCH_HEADER);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(currentDate().split(" ")[0]);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(currentDate().split(" ")[1]);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.COMMA_DELIMITER);
 * fileWriter.append(Constants.NEW_LINE_SEPARATOR); return fileWriter; }
 * 
 * private String formatDate(String saleDate) { SimpleDateFormat df_in = new
 * SimpleDateFormat("yyyyMMdd"); SimpleDateFormat df_output = new
 * SimpleDateFormat("MM/dd/yyyy"); String parsedDate = null; try { parsedDate =
 * df_output.format(df_in.parse(saleDate)); } catch (ParseException e) {
 * e.printStackTrace(); } return parsedDate; }
 * 
 * private String currentDate(){ DateFormat dateFormat = new
 * SimpleDateFormat("MM/dd/yyyy HH:mm"); return dateFormat.format(new Date()); }
 * 
 * private boolean validateMultiplePSAsPerStore(String[] tokens, Map<String,
 * List<String>> locationMap, StringBuffer sbMutilplePSA){ if(null ==
 * myConfig.getMultiplePSAsPerStore() ||
 * myConfig.getMultiplePSAsPerStore().equalsIgnoreCase("N")) { String line =
 * String.join(",", tokens); if
 * (locationMap.containsKey(tokens[Constants.DATE_IDX] +
 * tokens[Constants.LOCATION_IDX])) { List locationLineList =
 * locationMap.get(tokens[Constants.DATE_IDX] + tokens[Constants.LOCATION_IDX]);
 * if (locationLineList.size() == 1){
 * sbMutilplePSA.append(locationLineList.get(0)+"\n"); }
 * sbMutilplePSA.append(line+"\n"); locationLineList.add(line); } else {
 * List<String> lineList = new ArrayList(); lineList.add(line);
 * locationMap.put(tokens[Constants.DATE_IDX] + tokens[Constants.LOCATION_IDX],
 * lineList); } } return (sbMutilplePSA.length() > 0) ? true : false; }
 * 
 * 
 * }
 */