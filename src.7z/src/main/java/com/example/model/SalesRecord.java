package com.example.model;



import java.math.BigDecimal;


public class SalesRecord {

    private String date;
    private String location;
    private String itemType;
    private BigDecimal totalSales;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public BigDecimal getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}
	public SalesRecord(String date, String location, String itemType, BigDecimal totalSales) {
		super();
		this.date = date;
		this.location = location;
		this.itemType = itemType;
		this.totalSales = totalSales;
	}

}
