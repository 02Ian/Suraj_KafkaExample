package com.example.util;

public class Constants {

    public static final String NEW_LINE_SEPARATOR = "\r\n";
    public static final String COMMA_DELIMITER = ",";
    public static final int DATE_IDX = 0;
    public static final int LOCATION_IDX = 1;
    public static final int ITEM_TYPE_IDX = 2;
    public static final int TOTALSALES_IDX = 3;
    public static final int INPUT_TOKEN_LENGTH = 4;

    public static final String CONSTANT_ZERO = "0";
    public static final String CONSTANT_ONE = "1";
    public static final String CONSTANT_BLANK = "";
    public static final String CONSTANT_LAREDO_TACO = "LaredoTaco$";

    public static final String CONSTANT_BATCH_HEADER = "B";
    public static final String CONSTANT_PAPERWRK_HEADER = "PWK";
    public static final String CONSTANT_FORMS_DATA = "DID";
    public static final String CONSTANT_PAPERWRK_TRAILER = "PWKZ";
    public static final String CONSTANT_BATCH_TRAILER = "Z";
    //public static final String PDI_SHARED_PATH = "\\\\c185-217.c185.local\\EnterpriseDataTest\\US_Company_001\\DR\\Imports\\RIS\\LAREDO.txt";

}
