package com.example.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.example.config.YAMLConfig;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

@Service
public class Consumer {

	
	  @Autowired private YAMLConfig myConfig;
	 

	private final Logger logger = LoggerFactory.getLogger(Producer.class);

	@KafkaListener(topics = "test2", groupId = "group_id")
	public void consume(String message) throws IOException {
		logger.info(String.format("#### -> Consumed message -> %s", message));
		
		
		  logger.info("Horizon PDI location path: {} " + myConfig.getPdipath());
		  
		  NtlmPasswordAuthentication auth = new
		  NtlmPasswordAuthentication(myConfig.getDomain(), myConfig.getPdiUsername(),
		  myConfig.getPdiPassword());
		  
		  SmbFile sFile = new SmbFile(myConfig.getPdipath(), auth);
		  
		  SmbFileOutputStream sfos = new SmbFileOutputStream(sFile);
		  sfos.write(message.getBytes()); 
		  sfos.close();
		 

	}
}
